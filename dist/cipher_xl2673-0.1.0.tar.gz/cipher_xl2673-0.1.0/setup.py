# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cipher_xl2673']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'cipher-xl2673',
    'version': '0.1.0',
    'description': 'Building my first experimental Python package',
    'long_description': None,
    'author': 'Grace',
    'author_email': 'xl2673@columbia.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
